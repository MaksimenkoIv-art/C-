﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace kt5Maksimenko
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Product product1 = new Product("БрБр", 1000);
            Product product2 = new Product("шоколадный мишка для максика", 500);
            Product product3 = new Product("Калаш", 50000);
            Cart myCart = new Cart();
            myCart.AddProduct(product1);
            myCart.AddProduct(product2);
            myCart.AddProduct(product3);
            myCart.ShowCart();
            int total = myCart.GetTotal();
            Console.WriteLine($"\nсумма к оплате - {total} рублей");
        }

    }
    //продукт
    public class Product
    {
        public string Name { get; set; }
        public int Price { get; set; }
        public Product(string name, int price)
        {
            Name = name;
            Price = price;
        }
    }
    //корзина
    public class Cart
    {
        private List<Product> products = new List<Product>();

        //добавить
        public void AddProduct(Product product)
        {
            products.Add(product);
            Console.WriteLine($"так называемый'{product.Name}'добавлен в корзину");
        }
        //общ
        public int GetTotal()
        {
            int total = 0;
            for (int i = 0; i < products.Count; i++)
            {
                total += products[i].Price;
            }
            return total;
        }
        //показ_корзина
        public void ShowCart()
        {
            Console.WriteLine("карт : ");
            for (int i = 0; i < products.Count; i++)
            {
                Console.WriteLine($"{i + i}.{products[i].Name} - {products[i].Price} рублей");
            }
        }
    }

}
